const express = require('express');

const { getMessages, sendMessage, getUserConversations, createOrGetConversation } = require('../controllers/messageController');

// baqi routes wese hi rahenge...

const router = express.Router();

router.post('/conversation', createOrGetConversation);
router.get('/conversation/:userId', getUserConversations);
router.post('/message', sendMessage);
router.get('/message/:conversationId', getMessages);
module.exports = router;