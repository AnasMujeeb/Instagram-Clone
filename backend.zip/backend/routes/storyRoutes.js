const express = require('express');
const router = express.Router();
const { protect } = require('../middleware/authMiddleware');
const upload = require('../middleware/upload'); // Aapka multer/cloudinary middleware jo posts mein use ho raha hai
const { createStory, getStories, viewStory } = require('../controllers/storyController');

router.post('/', protect, upload.single('image'), createStory);
router.get('/', protect, getStories);
router.put('/:id/view', protect, viewStory);

module.exports = router;