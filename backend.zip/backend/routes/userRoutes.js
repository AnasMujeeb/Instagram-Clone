const express = require('express');
const router = express.Router();
const { getUserProfile, followUser, updateProfile, searchUsers, getSuggestions, toggleSavePost, getSavedPosts } = require('../controllers/userController');
const { protect } = require('../middleware/authMiddleware');
const { upload } = require('../config/cloudinary');

// These must come BEFORE /:id to avoid param conflict
router.get('/search', protect, searchUsers);
router.get('/saved', protect, getSavedPosts);
router.post('/save/:id', protect, toggleSavePost);
router.get('/suggestions', protect, getSuggestions);
router.put('/profile/update', protect, upload.single('profilePic'), updateProfile);

router.get('/:id', protect, getUserProfile);
router.put('/:id/follow', protect, followUser);

module.exports = router;