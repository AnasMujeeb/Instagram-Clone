const express = require('express');
const router = express.Router();
const { protect } = require('../middleware/authMiddleware');
const upload = require('../middleware/upload'); // Multer middleware jo videos ko bhi support kare
const { createReel, getReels, likeReel, addReelComment } = require('../controllers/reelController');

router.post('/', protect, upload.single('video'), createReel);
router.get('/', protect, getReels);
router.put('/:id/like', protect, likeReel);
router.post('/:id/comment', protect, addReelComment);

module.exports = router;