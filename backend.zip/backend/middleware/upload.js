const multer = require('multer');
const { CloudinaryStorage } = require('multer-storage-cloudinary');
const cloudinary = require('cloudinary').v2;

// Cloudinary configuration (agar aapne pehle se config.js mein ki hui hai toh yeh optional hai, par yahan honay se safe rehta hai)
cloudinary.config({
  cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
  api_key: process.env.CLOUDINARY_API_KEY,
  api_secret: process.env.CLOUDINARY_API_SECRET,
});

const storage = new CloudinaryStorage({
  cloudinary: cloudinary,
  params: {
    folder: 'instagram-clone',
    resource_type: 'auto', // Yeh images aur videos dono ko automatically detect kar ke upload karega (Reels aur Stories ke liye bohot zaroori hai)
  },
});

const upload = multer({ storage: storage });

module.exports = upload;