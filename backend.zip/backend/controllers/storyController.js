const Story = require('../models/Story');
const User = require('../models/User');

// Create a new story
const createStory = async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ message: 'Please upload an image for the story' });
    }

    const story = await Story.create({
      user: req.user._id,
      image: req.file.path,
    });

    const populatedStory = await story.populate('user', 'username profilePic name');
    res.status(201).json(populatedStory);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Get stories of current user and followed users
const getStories = async (req, res) => {
  try {
    const currentUser = await User.findById(req.user._id);
    if (!currentUser) {
      return res.status(404).json({ message: 'User not found' });
    }

    // Apni ID aur jinhein follow kiya hua hai un sab ki IDs
    const userIds = [req.user._id, ...currentUser.following];

    const stories = await Story.find({ user: { $in: userIds } })
      .populate('user', 'username profilePic name')
      .sort({ createdAt: -1 });

    // Stories ko user-wise group karna taake frontend par circle/ring mein show ho sakein
    const groupedStoriesMap = {};
    stories.forEach((story) => {
      if (!story.user) return;
      const userId = story.user._id.toString();
      if (!groupedStoriesMap[userId]) {
        groupedStoriesMap[userId] = {
          user: story.user,
          stories: [],
        };
      }
      groupedStoriesMap[userId].stories.push(story);
    });

    const result = Object.values(groupedStoriesMap);
    res.status(200).json(result);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Mark story as viewed
const viewStory = async (req, res) => {
  try {
    const story = await Story.findById(req.params.id);
    if (!story) {
      return res.status(404).json({ message: 'Story not found' });
    }

    if (!story.viewers.includes(req.user._id)) {
      story.viewers.push(req.user._id);
      await story.save();
    }

    res.status(200).json({ message: 'Story viewed successfully' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

module.exports = { createStory, getStories, viewStory };