const  Conversation = require('../models/Conversation.js');
const Message = require('../models/Message.js');

const createOrGetConversation = async (req, res) => {
  try {
    const { senderId, receiverId } = req.body;
    
    let conversation = await Conversation.findOne({
      members: { $all: [senderId, receiverId] },
    });

    if (!conversation) {
      conversation = new Conversation({
        members: [senderId, receiverId],
      });
      await conversation.save();
    }

    res.status(200).json(conversation);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

const getUserConversations = async (req, res) => {
  try {
    const conversations = await Conversation.find({
      members: { $in: [req.params.userId] },
    }).populate('members', 'username profilePic name');
    res.status(200).json(conversations);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};


const sendMessage = async (req, res) => {
  try {
    const { conversationId, sender, text } = req.body;
    const newMessage = new Message({ conversationId, sender, text });
    const savedMessage = await newMessage.save();
    res.status(200).json(savedMessage);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

const getMessages = async (req, res) => {
  try {
    const messages = await Message.find({
      conversationId: req.params.conversationId,
    });
    res.status(200).json(messages);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
module.exports = {getMessages,sendMessage,getUserConversations,createOrGetConversation};