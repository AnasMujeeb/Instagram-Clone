const Reel = require('../models/Reel');

// Create a new reel
const createReel = async (req, res) => {
  try {
    const { caption } = req.body;

    if (!req.file) {
      return res.status(400).json({ message: 'Please upload a video for the reel' });
    }

    const reel = await Reel.create({
      user: req.user._id,
      videoUrl: req.file.path,
      caption: caption || '',
    });

    const populatedReel = await reel.populate('user', 'username profilePic name');
    res.status(201).json(populatedReel);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Get all reels feed
const getReels = async (req, res) => {
  try {
    const reels = await Reel.find()
      .populate('user', 'username profilePic name')
      .populate('comments.user', 'username profilePic name')
      .sort({ createdAt: -1 });

    res.status(200).json(reels);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Like or Unlike a reel
const likeReel = async (req, res) => {
  try {
    const reel = await Reel.findById(req.params.id);
    if (!reel) {
      return res.status(404).json({ message: 'Reel not found' });
    }

    if (reel.likes.includes(req.user._id)) {
      reel.likes = reel.likes.filter((id) => id.toString() !== req.user._id.toString());
      await reel.save();
      return res.status(200).json({ message: 'Reel unliked', likesCount: reel.likes.length });
    } else {
      reel.likes.push(req.user._id);
      await reel.save();
      return res.status(200).json({ message: 'Reel liked', likesCount: reel.likes.length });
    }
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Add comment to a reel
const addReelComment = async (req, res) => {
  try {
    const { text } = req.body;
    if (!text) {
      return res.status(400).json({ message: 'Comment text cannot be empty' });
    }

    const reel = await Reel.findById(req.params.id);
    if (!reel) {
      return res.status(404).json({ message: 'Reel not found' });
    }

    reel.comments.push({
      user: req.user._id,
      text,
    });
    await reel.save();

    const updatedReel = await Reel.findById(req.params.id)
      .populate('user', 'username profilePic name')
      .populate('comments.user', 'username profilePic name');

    res.status(200).json(updatedReel.comments);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

module.exports = { createReel, getReels, likeReel, addReelComment };