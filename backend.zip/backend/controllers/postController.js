const Post = require('../models/Post');
const User = require('../models/User');
const Notification = require('../models/Notification');

const createPost = async (req, res) => {
  try {
    const { content } = req.body; 

    if (!content && !req.file) {
      return res.status(400).json({ message: 'Please add some content or an image for the post' });
    }

  
    const imageUrl = req.file ? req.file.path : '';

    const newPost = await Post.create({
      user: req.user._id, 
      content: content || '',
      image: imageUrl
    });

    const populatedPost = await newPost.populate('user', 'username profilePic name');
    res.status(201).json(populatedPost);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

const getPosts = async (req, res) => {
  try {
    const posts = await Post.find()
      .populate('user', 'username profilePic')
      .populate('comments.user', 'username profilePic')
      .sort({ createdAt: -1 }); 

    res.status(200).json(posts);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};


const likePost = async (req, res) => {
  try {
    const post = await Post.findById(req.params.id);

    if (!post) {
      return res.status(404).json({ message: 'Post not found' });
    }

    if (post.likes.includes(req.user._id)) {
      
      post.likes = post.likes.filter((id) => id.toString() !== req.user._id.toString());
      await post.save();
      return res.status(200).json({ message: 'Post unliked', likesCount: post.likes.length });
    } else {
      post.likes.push(req.user._id);
      await post.save();
      return res.status(200).json({ message: 'Post liked', likesCount: post.likes.length });
    }
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

const addComment = async (req, res) => {
  try {
    const { text } = req.body;

    if (!text) {
      return res.status(400).json({ message: 'Comment text cannot be empty' });
    }

    const post = await Post.findById(req.params.id);

    if (!post) {
      return res.status(404).json({ message: 'Post not found' });
    }

    const newComment = {
      user: req.user._id,
      text,
      createdAt: new Date()
    };

    post.comments.push(newComment);
    await post.save();

    const updatedPost = await Post.findById(req.params.id)
      .populate('user', 'username profilePic')
      .populate('comments.user', 'username profilePic');

    // Create comment notification for the post owner (skip self-comment)
    if (post.user.toString() !== req.user._id.toString()) {
      try {
        const notification = await Notification.create({
          recipient: post.user,
          sender: req.user._id,
          type: 'comment',
          postId: post._id,
          message: `${req.user.username || 'Someone'} commented on your post: "${text.slice(0, 50)}"`,
        });

        const populatedNotification = await notification.populate('sender', 'username profilePic name');

        // Emit real-time notification via Socket.io
        const { getIO, getOnlineUsers } = require('../socket');
        const io = getIO();
        const onlineUsers = getOnlineUsers();
        const receiverSocketId = onlineUsers.get(post.user.toString());
        if (receiverSocketId) {
          io.to(receiverSocketId).emit('newNotification', populatedNotification);
        }
      } catch (notifErr) {
        console.error('Failed to create notification:', notifErr);
      }
    }

    res.status(200).json(updatedPost.comments);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

const deletePost = async (req, res) => {
  try {
    const post = await Post.findById(req.params.id);
    if (!post) {
      return res.status(404).json({ message: 'Post not found' });
    }
    

    if (post.user.toString() !== req.user._id.toString()) {
      return res.status(401).json({ message: 'Not authorized to delete this post' });
    }

    await post.deleteOne();
    res.status(200).json({ message: 'Post deleted successfully' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};


const getTimelinePosts = async (req, res) => {
  try {
    const currentUser = await User.findById(req.user._id);
    
    
    const userPosts = await Post.find({ user: currentUser._id })
      .populate('user', 'username profilePic')
      .populate('comments.user', 'username profilePic');

    
    const friendPosts = await Promise.all(
      currentUser.following.map((friendId) => {
        return Post.find({ user: friendId })
          .populate('user', 'username profilePic')
          .populate('comments.user', 'username profilePic');
      })
    );

    const allPosts = userPosts.concat(...friendPosts).sort((a, b) => b.createdAt - a.createdAt);
    res.status(200).json(allPosts);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};



module.exports = { createPost, getPosts, likePost, addComment, deletePost, getTimelinePosts };