const { Server } = require('socket.io');
const Message = require('./models/Message');

let io;
const onlineUsers = new Map(); // userId -> socketId

function initSocket(httpServer) {
  io = new Server(httpServer, {
    cors: {
      origin: '*',
      methods: ['GET', 'POST', 'PUT', 'DELETE'],
    },
  });

  io.on('connection', (socket) => {
    console.log('Socket connected:', socket.id);

    // User joins with their userId after login
    socket.on('join', (userId) => {
      if (userId) {
        onlineUsers.set(userId, socket.id);
        io.emit('onlineUsers', Array.from(onlineUsers.keys()));
        console.log(`User ${userId} joined. Online users: ${onlineUsers.size}`);
      }
    });

    // Real-time messaging
    socket.on('sendMessage', async (data) => {
      // data: { conversationId, sender, receiverId, text }
      try {
        const newMessage = new Message({
          conversationId: data.conversationId,
          sender: data.sender,
          text: data.text,
        });
        const savedMessage = await newMessage.save();

        // Send to receiver if they are online
        const receiverSocketId = onlineUsers.get(data.receiverId);
        if (receiverSocketId) {
          io.to(receiverSocketId).emit('receiveMessage', {
            ...savedMessage.toObject(),
            conversationId: data.conversationId,
          });
        }

        // Send back to sender to confirm
        socket.emit('messageSent', savedMessage.toObject());
      } catch (err) {
        console.error('Socket sendMessage error:', err);
        socket.emit('messageError', { error: 'Failed to send message' });
      }
    });

    // Disconnect
    socket.on('disconnect', () => {
      for (const [userId, sId] of onlineUsers.entries()) {
        if (sId === socket.id) {
          onlineUsers.delete(userId);
          break;
        }
      }
      io.emit('onlineUsers', Array.from(onlineUsers.keys()));
      console.log('Socket disconnected:', socket.id, '- Online users:', onlineUsers.size);
    });
  });

  return io;
}

function getIO() {
  return io;
}

function getOnlineUsers() {
  return onlineUsers;
}

module.exports = { initSocket, getIO, getOnlineUsers };
