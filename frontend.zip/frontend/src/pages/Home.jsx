import { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

// ─── Helper: Time Ago ────────────────────────────────────────────────────────
function timeAgo(dateStr) {
  const seconds = Math.floor((Date.now() - new Date(dateStr)) / 1000);
  if (seconds < 60) return 'JUST NOW';
  const minutes = Math.floor(seconds / 60);
  if (minutes < 60) return `${minutes} MINUTE${minutes > 1 ? 'S' : ''} AGO`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours} HOUR${hours > 1 ? 'S' : ''} AGO`;
  const days = Math.floor(hours / 24);
  if (days < 7) return `${days} DAY${days > 1 ? 'S' : ''} AGO`;
  const weeks = Math.floor(days / 7);
  return `${weeks} WEEK${weeks > 1 ? 'S' : ''} AGO`;
}

// ─── Mock Stories Data ───────────────────────────────────────────────────────
const MOCK_STORIES = [
  { id: 'you', username: 'Your story', isYou: true },
  { id: 's1', username: 'saif.dev' },
  { id: 's2', username: 'zainab_art' },
  { id: 's3', username: 'ahmed.codes' },
  { id: 's4', username: 'sara_photo' },
  { id: 's5', username: 'ali.design' },
  { id: 's6', username: 'maira_ux' },
  { id: 's7', username: 'hamza.js' },
  { id: 's8', username: 'ayesha.ai' },
  { id: 's9', username: 'bilal_dev' },
];

// ─── SVG Icons ───────────────────────────────────────────────────────────────
const HeartIcon = ({ filled }) => filled ? (
  <svg aria-label="Unlike" fill="#ff3040" height="24" width="24" viewBox="0 0 48 48">
    <path d="M34.6 3.1c-4.5 0-7.9 1.8-10.6 5.6-2.7-3.7-6.1-5.5-10.6-5.5C6 3.1 0 9.6 0 17.6c0 7.3 5.4 12 10.6 16.5.6.5 1.3 1.1 1.9 1.7l2.3 2c4.4 3.9 6.6 5.9 7.6 6.5.5.3 1.1.5 1.6.5s1.1-.2 1.6-.5c1-.6 2.8-2.2 7.8-6.8l2-1.8c.7-.6 1.3-1.2 2-1.7C42.7 29.6 48 25 48 17.6c0-8-6-14.5-13.4-14.5Z"/>
  </svg>
) : (
  <svg aria-label="Like" fill="currentColor" height="24" width="24" viewBox="0 0 24 24">
    <path d="M16.792 3.904A4.989 4.989 0 0 1 21.5 9.122c0 3.072-2.652 4.959-5.197 7.222-2.512 2.243-3.865 3.469-4.303 3.752-.477-.309-2.143-1.823-4.303-3.752C5.141 14.072 2.5 12.167 2.5 9.122a4.989 4.989 0 0 1 4.708-5.218 4.21 4.21 0 0 1 3.675 1.941c.84 1.175.98 1.763 1.12 1.763s.278-.588 1.11-1.766a4.17 4.17 0 0 1 3.679-1.938m0-2a6.04 6.04 0 0 0-4.797 2.127 6.052 6.052 0 0 0-4.787-2.127A6.985 6.985 0 0 0 .5 9.122c0 3.61 2.55 5.827 5.015 7.97.283.246.569.494.853.747l1.027.918a44.998 44.998 0 0 0 3.518 3.018 2 2 0 0 0 2.174 0 45.263 45.263 0 0 0 3.626-3.115l.922-.824c.293-.26.59-.519.885-.774 2.334-2.025 4.98-4.32 4.98-7.94a6.985 6.985 0 0 0-6.708-7.218Z"/>
  </svg>
);

const CommentIcon = () => (
  <svg aria-label="Comment" fill="currentColor" height="24" width="24" viewBox="0 0 24 24">
    <path d="M20.656 17.008a9.993 9.993 0 1 0-3.59 3.615L22 22Z" fill="none" stroke="currentColor" strokeLinejoin="round" strokeWidth="2"/>
  </svg>
);

const ShareIcon = () => (
  <svg aria-label="Share Post" fill="currentColor" height="24" width="24" viewBox="0 0 24 24">
    <line fill="none" stroke="currentColor" strokeLinejoin="round" strokeWidth="2" x1="22" x2="9.218" y1="3" y2="10.083"/>
    <polygon fill="none" points="11.698 20.334 22 3.001 2 3.001 9.218 10.084 11.698 20.334" stroke="currentColor" strokeLinejoin="round" strokeWidth="2"/>
  </svg>
);

const BookmarkIcon = ({ filled }) => filled ? (
  <svg aria-label="Remove" fill="currentColor" height="24" width="24" viewBox="0 0 24 24">
    <path d="M20 22a.999.999 0 0 1-.687-.273L12 14.815l-7.313 6.912A1 1 0 0 1 3 21V3a1 1 0 0 1 1-1h16a1 1 0 0 1 1 1v18a1 1 0 0 1-1 1Z"/>
  </svg>
) : (
  <svg aria-label="Save" fill="currentColor" height="24" width="24" viewBox="0 0 24 24">
    <polygon fill="none" points="20 21 12 13.44 4 21 4 3 20 3 20 21" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2"/>
  </svg>
);

const MoreIcon = () => (
  <svg aria-label="More options" fill="currentColor" height="24" width="24" viewBox="0 0 24 24">
    <circle cx="12" cy="12" r="1.5"/><circle cx="6" cy="12" r="1.5"/><circle cx="18" cy="12" r="1.5"/>
  </svg>
);

const EmojiIcon = () => (
  <svg aria-label="Emoji" fill="currentColor" height="24" width="24" viewBox="0 0 24 24">
    <path d="M15.83 10.997a1.167 1.167 0 1 0 1.167 1.167 1.167 1.167 0 0 0-1.167-1.167Zm-6.5 1.167a1.167 1.167 0 1 0-1.166 1.167 1.167 1.167 0 0 0 1.166-1.167Zm5.163 3.24a3.406 3.406 0 0 1-4.982.007 1 1 0 1 0-1.557 1.256 5.397 5.397 0 0 0 8.09 0 1 1 0 0 0-1.55-1.263ZM12 .503a11.5 11.5 0 1 0 11.5 11.5A11.513 11.513 0 0 0 12 .503Zm0 21a9.5 9.5 0 1 1 9.5-9.5 9.51 9.51 0 0 1-9.5 9.5Z"/>
  </svg>
);

export default function Home() {
  const [user, setUser] = useState(null);
  const [posts, setPosts] = useState([]);
  const [content, setContent] = useState('');
  const [image, setImage] = useState(null);
  const [imagePreview, setImagePreview] = useState(null);
  const [error, setError] = useState('');
  const [commentInputs, setCommentInputs] = useState({});
  const [savedPosts, setSavedPosts] = useState(new Set());
  const [expandedCaptions, setExpandedCaptions] = useState(new Set());
  const [showCreatePost, setShowCreatePost] = useState(false);
  const storiesRef = useRef(null);
  const navigate = useNavigate();

  useEffect(() => {
    const storedUser = localStorage.getItem('user');
    if (!storedUser) {
      navigate('/login');
    } else {
      const parsed = JSON.parse(storedUser);
      setUser(parsed);
      fetchPosts(parsed.token);
      fetchSavedPosts(parsed.token);
    }
  }, [navigate]);

  const fetchSavedPosts = async (token) => {
    try {
      const res = await axios.get('http://localhost:5002/api/users/saved', {
        headers: { Authorization: `Bearer ${token}` },
      });
      const ids = new Set(res.data.map((post) => post._id));
      setSavedPosts(ids);
    } catch (err) {
      console.error('Failed to fetch saved posts:', err);
    }
  };

  const fetchPosts = async (token) => {
    try {
      const response = await axios.get('http://localhost:5002/api/posts', {
        headers: { Authorization: `Bearer ${token}` },
      });
      setPosts(response.data);
    } catch (err) {
      console.error(err);
    }
  };

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setImage(file);
      setImagePreview(URL.createObjectURL(file));
    }
  };

  const handleCreatePost = async (e) => {
    e.preventDefault();
    if (!content.trim() && !image) return;

    try {
      const formData = new FormData();
      formData.append('content', content);
      if (image) {
        formData.append('image', image);
      }

      const response = await axios.post(
        'http://localhost:5002/api/posts',
        formData,
        { 
          headers: { 
            Authorization: `Bearer ${user.token}`,
            'Content-Type': 'multipart/form-data' 
          } 
        }
      );

      setPosts([response.data, ...posts]);
      setContent('');
      setImage(null);
      setImagePreview(null);
      setError('');
      setShowCreatePost(false);
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to create post');
    }
  };

  const handleLike = async (postId) => {
    const post = posts.find(p => p._id === postId);
    if (!post) return;
    
    const alreadyLiked = post.likes && post.likes.includes(user._id);
    const updatedLikes = alreadyLiked
      ? post.likes.filter(id => id !== user._id)
      : [...(post.likes || []), user._id];
    
    setPosts(posts.map(p => p._id === postId ? { ...p, likes: updatedLikes } : p));

    try {
      await axios.put(
        `http://localhost:5002/api/posts/${postId}/like`,
        {},
        { headers: { Authorization: `Bearer ${user.token}` } }
      );
    } catch (err) {
      setPosts(posts.map(p => p._id === postId ? { ...p, likes: post.likes } : p));
      console.error(err);
    }
  };

  const handleCommentChange = (postId, value) => {
    setCommentInputs({ ...commentInputs, [postId]: value });
  };

  const handleAddComment = async (e, postId) => {
    e.preventDefault();
    const commentText = commentInputs[postId];
    if (!commentText || !commentText.trim()) return;

    try {
      const response = await axios.post(
        `http://localhost:5002/api/posts/${postId}/comment`,
        { text: commentText },
        { headers: { Authorization: `Bearer ${user.token}` } }
      );
      setPosts(posts.map(p => p._id === postId ? { ...p, comments: response.data } : p));
      setCommentInputs({ ...commentInputs, [postId]: '' });
    } catch (err) {
      console.error(err);
    }
  };

  const toggleSave = async (postId) => {
    const wasSaved = savedPosts.has(postId);
    setSavedPosts(prev => {
      const next = new Set(prev);
      wasSaved ? next.delete(postId) : next.add(postId);
      return next;
    });

    try {
      const res = await axios.post(
        `http://localhost:5002/api/users/save/${postId}`,
        {},
        { headers: { Authorization: `Bearer ${user.token}` } }
      );
      setSavedPosts(prev => {
        const next = new Set(prev);
        res.data.saved ? next.add(postId) : next.delete(postId);
        return next;
      });
    } catch (err) {
      setSavedPosts(prev => {
        const next = new Set(prev);
        wasSaved ? next.add(postId) : next.delete(postId);
        return next;
      });
      console.error('Save error:', err);
    }
  };

  const toggleCaption = (postId) => {
    setExpandedCaptions(prev => {
      const next = new Set(prev);
      next.has(postId) ? next.delete(postId) : next.add(postId);
      return next;
    });
  };

  if (!user) return null;

  return (
    <div className="min-h-screen bg-black text-white flex flex-col items-center">
      <div className="w-full max-w-[470px] px-0 md:px-0 py-0 flex flex-col">

        {/* ═══ STORIES BAR ═══ */}
        <div className="w-full border-b border-zinc-800 bg-black py-4 mb-1">
          <div 
            ref={storiesRef}
            className="flex gap-4 overflow-x-auto scrollbar-hide px-4"
          >
            {MOCK_STORIES.map((story) => (
              <div key={story.id} className="flex flex-col items-center gap-1.5 flex-shrink-0 cursor-pointer group">
                {/* Story Ring - Static Gradient Border */}
                <div className={`w-[66px] h-[66px] rounded-full p-[3px] ${
                  story.isYou 
                    ? 'bg-zinc-800' 
                    : 'bg-gradient-to-tr from-amber-400 via-red-500 to-purple-600'
                }`}>
                  <div className="w-full h-full rounded-full bg-black p-[2px]">
                    <div className="w-full h-full rounded-full bg-zinc-800 flex items-center justify-center text-sm font-semibold text-white relative overflow-hidden">
                      {story.username[0].toUpperCase()}
                      {story.isYou && (
                        <div className="absolute bottom-0 right-0 w-5 h-5 bg-blue-500 rounded-full border-2 border-black flex items-center justify-center">
                          <span className="text-[12px] font-bold leading-none text-white">+</span>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
                <span className="text-[11px] text-zinc-400 w-[66px] text-center truncate group-hover:text-zinc-300 transition">
                  {story.isYou ? 'Your story' : story.username}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* ═══ CREATE POST TOGGLE ═══ */}
        <div className="px-0 pt-2">
          {!showCreatePost ? (
            <button 
              onClick={() => setShowCreatePost(true)}
              className="w-full py-3 text-sm text-zinc-500 hover:text-zinc-300 transition border-b border-zinc-800 cursor-pointer flex items-center justify-center gap-2"
            >
              <svg fill="currentColor" height="20" width="20" viewBox="0 0 24 24" className="text-zinc-500">
                <path d="M2 12v3.45c0 2.849.698 4.005 1.606 4.944.94.909 2.098 1.608 4.946 1.608h6.896c2.849 0 4.006-.7 4.946-1.608C21.302 19.455 22 18.3 22 15.45V8.552c0-2.849-.698-4.006-1.606-4.945C19.454 2.7 18.296 2 15.448 2H8.552c-2.848 0-4.006.699-4.946 1.607C2.698 4.547 2 5.703 2 8.552Z" fill="none" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
                <line fill="none" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" x1="6.545" x2="17.455" y1="12.001" y2="12.001" />
                <line fill="none" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" x1="12.003" x2="12.003" y1="6.545" y2="17.455" />
              </svg>
              Create new post
            </button>
          ) : (
            <div className="border border-zinc-800 rounded-xl bg-black mb-4 overflow-hidden">
              <div className="flex items-center justify-between px-4 py-3 border-b border-zinc-800">
                <button onClick={() => { setShowCreatePost(false); setImage(null); setImagePreview(null); setContent(''); }} className="text-sm text-zinc-400 hover:text-white transition cursor-pointer">Cancel</button>
                <span className="text-sm font-semibold">Create new post</span>
                <button onClick={handleCreatePost} className="text-sm font-semibold text-blue-500 hover:text-blue-400 transition cursor-pointer">Share</button>
              </div>
              {error && <div className="px-4 py-2 text-xs bg-red-500/10 text-red-400">{error}</div>}
              <form onSubmit={handleCreatePost} className="flex flex-col">
                {imagePreview && (
                  <div className="relative w-full aspect-square bg-zinc-950">
                    <img src={imagePreview} alt="Preview" className="w-full h-full object-cover" />
                    <button
                      type="button"
                      onClick={() => { setImage(null); setImagePreview(null); }}
                      className="absolute top-3 right-3 w-8 h-8 bg-black/70 backdrop-blur-sm rounded-full flex items-center justify-center text-white hover:bg-black transition cursor-pointer"
                    >
                      ✕
                    </button>
                  </div>
                )}
                <div className="p-4">
                  <textarea
                    value={content}
                    onChange={(e) => setContent(e.target.value)}
                    placeholder="Write a caption..."
                    rows="3"
                    className="w-full bg-transparent text-sm text-white placeholder-zinc-600 focus:outline-none resize-none"
                  />
                  <div className="flex items-center justify-between pt-3 border-t border-zinc-800 mt-2">
                    <label className="cursor-pointer text-zinc-400 hover:text-white transition flex items-center gap-2">
                      <svg fill="currentColor" height="20" width="20" viewBox="0 0 24 24">
                        <path d="M6.549 5.013A1.557 1.557 0 1 0 8.106 6.57a1.557 1.557 0 0 0-1.557-1.557ZM2 18.605l3.901-3.9a.908.908 0 0 1 1.284 0l2.807 2.806a.908.908 0 0 0 1.283 0l5.534-5.534a.908.908 0 0 1 1.283 0l3.905 3.905" fill="none" stroke="currentColor" strokeLinejoin="round" strokeWidth="2"/>
                        <path d="M18.44 2.004H5.56a3.556 3.556 0 0 0-3.556 3.556v12.88a3.556 3.556 0 0 0 3.556 3.556h12.88a3.556 3.556 0 0 0 3.556-3.556V5.56a3.556 3.556 0 0 0-3.556-3.556Z" fill="none" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2"/>
                      </svg>
                      <span className="text-xs font-medium">Photo</span>
                      <input type="file" accept="image/*" onChange={handleImageChange} className="hidden" />
                    </label>
                  </div>
                </div>
              </form>
            </div>
          )}
        </div>

        {/* ═══ POST FEED ═══ */}
        <div className="flex flex-col">
          {posts.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-20">
              <div className="w-16 h-16 border-2 border-zinc-700 rounded-full flex items-center justify-center mb-4">
                <svg fill="currentColor" height="32" width="32" viewBox="0 0 24 24" className="text-zinc-600">
                  <path d="M6.549 5.013A1.557 1.557 0 1 0 8.106 6.57a1.557 1.557 0 0 0-1.557-1.557ZM2 18.605l3.901-3.9a.908.908 0 0 1 1.284 0l2.807 2.806a.908.908 0 0 0 1.283 0l5.534-5.534a.908.908 0 0 1 1.283 0l3.905 3.905" fill="none" stroke="currentColor" strokeLinejoin="round" strokeWidth="2"/>
                  <path d="M18.44 2.004H5.56a3.556 3.556 0 0 0-3.556 3.556v12.88a3.556 3.556 0 0 0 3.556 3.556h12.88a3.556 3.556 0 0 0 3.556-3.556V5.56a3.556 3.556 0 0 0-3.556-3.556Z" fill="none" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2"/>
                </svg>
              </div>
              <p className="text-sm text-zinc-500">No posts yet. Share your first photo!</p>
            </div>
          ) : (
            posts.map((post) => {
              const isLiked = user && post.likes && post.likes.includes(user._id);
              const isSaved = savedPosts.has(post._id);
              const isExpanded = expandedCaptions.has(post._id);
              const captionIsLong = post.content && post.content.length > 100;

              return (
                <article key={post._id} className="border-b border-zinc-800 pb-1 mb-3">
                  {/* ── Post Header ── */}
                  <div className="flex items-center justify-between px-1 py-3">
                    <div className="flex items-center gap-3">
                      {/* Avatar with static gradient ring */}
                      <div className="w-[34px] h-[34px] rounded-full bg-gradient-to-tr from-amber-400 via-red-500 to-purple-600 p-[2px]">
                        <div className="w-full h-full rounded-full bg-black p-[1px]">
                          <div className="w-full h-full bg-zinc-800 rounded-full flex items-center justify-center text-[11px] font-bold text-white">
                            {post.user?.profilePic ? (
                              <img src={post.user.profilePic} alt="" className="w-full h-full rounded-full object-cover" />
                            ) : (
                              post.user?.username ? post.user.username[0].toUpperCase() : 'U'
                            )}
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <span className="font-semibold text-[13px] text-white hover:opacity-70 cursor-pointer transition">
                          {post.user?.username || 'user'}
                        </span>
                        <span className="text-zinc-500 text-[13px]">•</span>
                        <span className="text-zinc-500 text-[13px]">{timeAgo(post.createdAt)}</span>
                      </div>
                    </div>
                    <button className="text-white hover:opacity-60 transition cursor-pointer p-1">
                      <MoreIcon />
                    </button>
                  </div>

                  {/* ── Post Image ── */}
                  {post.image && (
                    <div className="w-full bg-black rounded-[4px] overflow-hidden border border-zinc-900">
                      <img 
                        src={post.image} 
                        alt="Post" 
                        className="w-full object-cover"
                        style={{ maxHeight: '585px' }}
                        onDoubleClick={() => handleLike(post._id)}
                      />
                    </div>
                  )}

                  {/* ── Action Bar ── */}
                  <div className="flex items-center justify-between pt-3 pb-1 px-1">
                    <div className="flex items-center gap-4">
                      <button 
                        onClick={() => handleLike(post._id)}
                        className={`hover:opacity-60 transition cursor-pointer ${isLiked ? 'animate-[like-heart_0.3s_ease]' : ''}`}
                      >
                        <HeartIcon filled={isLiked} />
                      </button>
                      <button className="text-white hover:opacity-60 transition cursor-pointer">
                        <CommentIcon />
                      </button>
                      <button className="text-white hover:opacity-60 transition cursor-pointer">
                        <ShareIcon />
                      </button>
                    </div>
                    <button 
                      onClick={() => toggleSave(post._id)}
                      className="text-white hover:opacity-60 transition cursor-pointer"
                    >
                      <BookmarkIcon filled={isSaved} />
                    </button>
                  </div>

                  {/* ── Likes Count ── */}
                  <div className="px-1 pt-1">
                    <button className="text-sm font-semibold text-white hover:opacity-70 transition cursor-pointer">
                      {post.likes ? post.likes.length : 0} likes
                    </button>
                  </div>

                  {/* ── Caption ── */}
                  {post.content && (
                    <div className="px-1 pt-1">
                      <p className="text-sm text-white">
                        <span className="font-semibold mr-1.5 hover:opacity-70 cursor-pointer transition">
                          {post.user?.username || 'user'}
                        </span>
                        {captionIsLong && !isExpanded ? (
                          <>
                            {post.content.slice(0, 100)}
                            <button onClick={() => toggleCaption(post._id)} className="text-zinc-500 ml-1 cursor-pointer">... more</button>
                          </>
                        ) : (
                          <span className="text-zinc-300">{post.content}</span>
                        )}
                      </p>
                    </div>
                  )}

                  {/* ── View All Comments ── */}
                  {post.comments && post.comments.length > 2 && (
                    <button className="px-1 pt-1 text-sm text-zinc-500 hover:text-zinc-400 transition cursor-pointer">
                      View all {post.comments.length} comments
                    </button>
                  )}

                  {/* ── Recent Comments (last 2) ── */}
                  {post.comments && post.comments.slice(-2).map((comment, index) => (
                    <div key={index} className="px-1 pt-0.5">
                      <p className="text-sm">
                        <span className="font-semibold text-white mr-1.5 hover:opacity-70 cursor-pointer transition">
                          {comment.user?.username || 'user'}
                        </span>
                        <span className="text-zinc-300">{comment.text}</span>
                      </p>
                    </div>
                  ))}

                  {/* ── Time Stamp ── */}
                  <div className="px-1 pt-2 pb-1">
                    <span className="text-[10px] text-zinc-600 uppercase tracking-wide">
                      {post.createdAt ? timeAgo(post.createdAt) : ''}
                    </span>
                  </div>

                  {/* ── Comment Input ── */}
                  <form onSubmit={(e) => handleAddComment(e, post._id)} className="flex items-center gap-3 px-1 py-3 border-t border-zinc-800 mt-1">
                    <button type="button" className="text-white hover:opacity-60 transition cursor-pointer flex-shrink-0">
                      <EmojiIcon />
                    </button>
                    <input
                      type="text"
                      placeholder="Add a comment..."
                      value={commentInputs[post._id] || ''}
                      onChange={(e) => handleCommentChange(post._id, e.target.value)}
                      className="flex-1 bg-transparent text-sm text-white placeholder-zinc-600 focus:outline-none"
                    />
                    {commentInputs[post._id]?.trim() && (
                      <button
                        type="submit"
                        className="text-sm font-semibold text-blue-500 hover:text-blue-300 transition cursor-pointer"
                      >
                        Post
                      </button>
                    )}
                  </form>
                </article>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
}