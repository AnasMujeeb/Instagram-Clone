import { useState, useRef, useEffect } from 'react';
import axios from 'axios';

// ─── Compact number formatter ────────────────────────────────────────────────
function formatCount(n) {
  if (n >= 1000000) return (n / 1000000).toFixed(1).replace(/\.0$/, '') + 'M';
  if (n >= 1000) return (n / 1000).toFixed(1).replace(/\.0$/, '') + 'K';
  return n.toString();
}

// ─── SVG Icons ───────────────────────────────────────────────────────────────
const HeartIcon = ({ filled }) => filled ? (
  <svg fill="#ff3040" height="28" width="28" viewBox="0 0 48 48">
    <path d="M34.6 3.1c-4.5 0-7.9 1.8-10.6 5.6-2.7-3.7-6.1-5.5-10.6-5.5C6 3.1 0 9.6 0 17.6c0 7.3 5.4 12 10.6 16.5.6.5 1.3 1.1 1.9 1.7l2.3 2c4.4 3.9 6.6 5.9 7.6 6.5.5.3 1.1.5 1.6.5s1.1-.2 1.6-.5c1-.6 2.8-2.2 7.8-6.8l2-1.8c.7-.6 1.3-1.2 2-1.7C42.7 29.6 48 25 48 17.6c0-8-6-14.5-13.4-14.5Z"/>
  </svg>
) : (
  <svg fill="white" height="28" width="28" viewBox="0 0 48 48">
    <path d="M34.6 3.1c-4.5 0-7.9 1.8-10.6 5.6-2.7-3.7-6.1-5.5-10.6-5.5C6 3.1 0 9.6 0 17.6c0 7.3 5.4 12 10.6 16.5.6.5 1.3 1.1 1.9 1.7l2.3 2c4.4 3.9 6.6 5.9 7.6 6.5.5.3 1.1.5 1.6.5s1.1-.2 1.6-.5c1-.6 2.8-2.2 7.8-6.8l2-1.8c.7-.6 1.3-1.2 2-1.7C42.7 29.6 48 25 48 17.6c0-8-6-14.5-13.4-14.5Z"/>
  </svg>
);

const CommentIcon = () => (
  <svg fill="white" height="28" width="28" viewBox="0 0 24 24">
    <path d="M20.656 17.008a9.993 9.993 0 1 0-3.59 3.615L22 22Z" fill="none" stroke="white" strokeLinejoin="round" strokeWidth="2"/>
  </svg>
);

const ShareIcon = () => (
  <svg fill="white" height="28" width="28" viewBox="0 0 24 24">
    <line fill="none" stroke="white" strokeLinejoin="round" strokeWidth="2" x1="22" x2="9.218" y1="3" y2="10.083"/>
    <polygon fill="none" points="11.698 20.334 22 3.001 2 3.001 9.218 10.084 11.698 20.334" stroke="white" strokeLinejoin="round" strokeWidth="2"/>
  </svg>
);

const MusicIcon = () => (
  <svg fill="white" height="16" width="16" viewBox="0 0 24 24">
    <path d="M12 3v10.55A4 4 0 1 0 14 17V7h4V3h-6Z"/>
  </svg>
);

const PlayIcon = () => (
  <svg fill="white" height="64" width="64" viewBox="0 0 24 24" opacity="0.8">
    <path d="M8 5v14l11-7z"/>
  </svg>
);

const MuteIcon = ({ muted }) => muted ? (
  <svg fill="white" height="16" width="16" viewBox="0 0 24 24">
    <path d="M16.5 12c0-1.77-1.02-3.29-2.5-4.03v2.21l2.45 2.45c.03-.2.05-.41.05-.63zm2.5 0c0 .94-.2 1.82-.54 2.64l1.51 1.51C20.63 14.91 21 13.5 21 12c0-4.28-2.99-7.86-7-8.77v2.06c2.89.86 5 3.54 5 6.71zM4.27 3L3 4.27 7.73 9H3v6h4l5 5v-6.73l4.25 4.25c-.67.52-1.42.93-2.25 1.18v2.06c1.38-.31 2.63-.95 3.69-1.81L19.73 21 21 19.73l-9-9L4.27 3zM12 4L9.91 6.09 12 8.18V4z"/>
  </svg>
) : (
  <svg fill="white" height="16" width="16" viewBox="0 0 24 24">
    <path d="M3 9v6h4l5 5V4L7 9H3zm13.5 3c0-1.77-1.02-3.29-2.5-4.03v8.05c1.48-.73 2.5-2.25 2.5-4.02zM14 3.23v2.06c2.89.86 5 3.54 5 6.71s-2.11 5.85-5 6.71v2.06c4.01-.91 7-4.49 7-8.77s-2.99-7.86-7-8.77z"/>
  </svg>
);

const BookmarkIcon = ({ filled }) => filled ? (
  <svg aria-label="Remove" color="white" fill="white" height="28" width="28" viewBox="0 0 24 24">
    <path d="M20 22a.999.999 0 0 1-.687-.273L12 14.815l-7.313 6.912A1 1 0 0 1 3 21V3a1 1 0 0 1 1-1h16a1 1 0 0 1 1 1v18a1 1 0 0 1-1 1Z"></path>
  </svg>
) : (
  <svg aria-label="Save" color="white" fill="transparent" height="28" width="28" viewBox="0 0 24 24" stroke="white" strokeWidth="2">
    <polygon fill="none" points="20 21 12 13.44 4 21 4 3 20 3 20 21" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round"></polygon>
  </svg>
);

// ─── Single Reel Component ───────────────────────────────────────────────────
function ReelCard({ reel, isActive }) {
  const videoRef = useRef(null);
  const [liked, setLiked] = useState(false);
  const [likesCount, setLikesCount] = useState(reel.likes || 0);
  const [paused, setPaused] = useState(false);
  const [muted, setMuted] = useState(true);
  const [showHeart, setShowHeart] = useState(false);
  const [isSaved, setIsSaved] = useState(false);

  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    if (isActive) {
      video.currentTime = 0;
      video.play().catch(() => {});
      setPaused(false);
    } else {
      video.pause();
    }
  }, [isActive]);

  const togglePlay = () => {
    const video = videoRef.current;
    if (!video) return;
    if (video.paused) {
      video.play().catch(() => {});
      setPaused(false);
    } else {
      video.pause();
      setPaused(true);
    }
  };

  const handleDoubleClick = () => {
    if (!liked) {
      setLiked(true);
      setLikesCount(prev => prev + 1);
    }
    setShowHeart(true);
    setTimeout(() => setShowHeart(false), 800);
  };

  const toggleLike = () => {
    setLiked(prev => !prev);
    setLikesCount(prev => liked ? prev - 1 : prev + 1);
  };

  const toggleMute = (e) => {
    e.stopPropagation();
    setMuted(prev => !prev);
    if (videoRef.current) {
      videoRef.current.muted = !muted;
    }
  };

  const handleSavePost = async () => {
    try {
      setIsSaved(!isSaved);

      const storedData = JSON.parse(localStorage.getItem('user'));
      const token = storedData?.token;

      const config = {
        headers: {
          Authorization: `Bearer ${token}`
        }
      };

      // Ab yahan real MongoDB _id jaegi jo database se fetch ho kar aayi hai
      await axios.post(`http://localhost:5002/api/users/save/${reel._id}`, {}, config);
      
    } catch (error) {
      console.log("Error saving post", error);
      setIsSaved(isSaved);
    }
  };

  return (
    <div className="reel-card">
      <video
        ref={videoRef}
        src={reel.videoUrl || reel.video} // Backend ke schema ke mutabiq field name adjust kar lena (jaise videoUrl)
        className="reel-video"
        loop
        muted={muted}
        playsInline
        onClick={togglePlay}
        onDoubleClick={handleDoubleClick}
      />

      {paused && (
        <div className="reel-pause-overlay" onClick={togglePlay}>
          <PlayIcon />
        </div>
      )}

      {showHeart && (
        <div className="reel-heart-animation">
          <svg fill="white" height="100" width="100" viewBox="0 0 48 48">
            <path d="M34.6 3.1c-4.5 0-7.9 1.8-10.6 5.6-2.7-3.7-6.1-5.5-10.6-5.5C6 3.1 0 9.6 0 17.6c0 7.3 5.4 12 10.6 16.5.6.5 1.3 1.1 1.9 1.7l2.3 2c4.4 3.9 6.6 5.9 7.6 6.5.5.3 1.1.5 1.6.5s1.1-.2 1.6-.5c1-.6 2.8-2.2 7.8-6.8l2-1.8c.7-.6 1.3-1.2 2-1.7C42.7 29.6 48 25 48 17.6c0-8-6-14.5-13.4-14.5Z"/>
          </svg>
        </div>
      )}

      <div className="reel-actions">
        <button className="reel-action-btn" onClick={toggleLike}>
          <HeartIcon filled={liked} />
          <span className="reel-action-count">{formatCount(likesCount)}</span>
        </button>
        
        <button className="reel-action-btn">
          <CommentIcon />
          <span className="reel-action-count">{formatCount(reel.comments?.length || 0)}</span>
        </button>
        
        <button className="reel-action-btn">
          <ShareIcon />
          <span className="reel-action-count">Share</span>
        </button>
        
        <button className="reel-action-btn" onClick={handleSavePost}>
          <BookmarkIcon filled={isSaved} />
        </button>

        <div className="reel-music-disc">
          <div className="reel-disc-inner" />
        </div>
      </div>

      <div className="reel-bottom-overlay">
        <div className="reel-user-row">
          <div className="reel-user-avatar">
            {reel.user?.username ? reel.user.username[0].toUpperCase() : 'U'}
          </div>
          <span className="reel-username">{reel.user?.username || reel.username || 'user'}</span>
          <button className="reel-follow-btn">Follow</button>
        </div>
        <p className="reel-caption">{reel.caption}</p>
        <div className="reel-song-row">
          <MusicIcon />
          <span className="reel-song-name">{reel.song || 'Original Audio'}</span>
        </div>
      </div>

      <button className="reel-mute-btn" onClick={toggleMute}>
        <MuteIcon muted={muted} />
      </button>
    </div>
  );
}

// ─── Reels Page ──────────────────────────────────────────────────────────────
export default function Reels() {
  const [reels, setReels] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeIndex, setActiveIndex] = useState(0);
  const containerRef = useRef(null);

  // Backend se real reels fetch karna
  useEffect(() => {
    const fetchReels = async () => {
      try {
        const storedData = JSON.parse(localStorage.getItem('user'));
        const token = storedData?.token;

        const res = await axios.get('http://localhost:5002/api/posts', {
          headers: { Authorization: `Bearer ${token}` }
        });
        
        // Agar tumhara endpoint sirf reels filter karta hai ya saari posts deta hai
        // Tum apne backend route ke mutabiq data set kar sakte ho (e.g., res.data)
        setReels(res.data);
        setLoading(false);
      } catch (error) {
        console.log("Error fetching reels:", error);
        setLoading(false);
      }
    };

    fetchReels();
  }, []);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const index = Number(entry.target.dataset.index);
            setActiveIndex(index);
          }
        });
      },
      { root: container, threshold: 0.7 }
    );

    const cards = container.querySelectorAll('.reel-card');
    cards.forEach((card) => observer.observe(card));

    return () => observer.observer ? observer.disconnect() : observer.disconnect();
  }, [reels]);

  if (loading) {
    return <div style={{ color: 'white', textAlign: 'center', marginTop: '50vh' }}>Loading reels...</div>;
  }

  if (reels.length === 0) {
    return <div style={{ color: 'white', textAlign: 'center', marginTop: '50vh' }}>No reels found!</div>;
  }

  return (
    <div className="reels-container" ref={containerRef}>
      {reels.map((reel, index) => (
        <div key={reel._id} data-index={index}>
          <ReelCard reel={reel} isActive={index === activeIndex} />
        </div>
      ))}
    </div>
  );
} 